from matplotlib import pyplot as plt

plt.figure(figsize = (3,3))
x = [0,0,4.33,0]
y = [5,0,2.5,5]

plt.plot(x,y)
plt.show()
