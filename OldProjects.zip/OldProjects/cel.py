cel_list = [21,0,7.2,-8.9,-30]
far_list = []


def celsiuse_to_fahrenheit(c):
    return (9/5)*c+32


for i in cel_list:
    convert = celsiuse_to_fahrenheit(i)
    far_list.append(convert)

print("")
print("Farenheit:",far_list)
print("")
print("Celsiuse:", cel_list)
