import time
Q = input("how many times would you like me to run?")
Q = int(Q)
for X in range(0,Q):
    print("Hello")