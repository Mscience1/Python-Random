def final_grade(grade):
    percentage = [10,30,20]
    points_list = []
    avg = sum(grade) / len(grade)
    print("Average:",avg)

    for i in range(0,len(grade)):

        points = grade[i]*(percentage[i]/100)
        points_list.append(points)

    return sum(points_list)

print("Weighted Percent:",final_grade([95,92,93]))


