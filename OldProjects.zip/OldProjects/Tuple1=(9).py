tuple1 = (9)
#not a tuple because your missing a comma

