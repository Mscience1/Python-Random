dict_old = {"Hyperloop": "One", "LHC": "Particle Accelerator","Michael":"Human"}
dict_new = dict(zip(dict_old.values(),zip(dict_old.keys())))
print(dict_new)