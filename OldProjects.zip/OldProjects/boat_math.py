import numpy

v_torpedo = 50
v_boat = 20
y_boat = 500
x_boat = 0
y_torpedo = 0
x_torpedo = 0


v_torpedo = v_torpedo/3.6
v_boat = v_boat/3.6

dt = 1
t=0

while(True):
    if(y_torpedo<y_boat):
        d = numpy.sqrt((y_boat-y_torpedo)**2+(x_boat-x_torpedo)**2)
        x_torpedo += v_torpedo*dt*(x_boat-x_torpedo)/d
        y_torpedo += v_torpedo*dt*(y_boat-y_torpedo)/d
        x_boat += v_boat*dt
        t+=dt

    else:
        break

print(t)
