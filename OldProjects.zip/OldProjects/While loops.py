Number1 = 0

list = []

while(Number1 < 999):

    Number1 = Number1 + 1

    if Number1%5 == 0:
        list.append(Number1)

    elif Number1%3 == 0:
        list.append(Number1)

    print(".........")
    print(sum(list))
