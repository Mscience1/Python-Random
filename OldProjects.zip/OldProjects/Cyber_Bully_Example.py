from tkinter import *
import tkinter
from tkinter import messagebox

root = Tk()
root.configure(background = "black")
root.geometry("1000x600")
root.title("Bullies Beware!!!")

def upload_now():
    messagebox._show("Found Match", "Similar Image Found In Bullying Database")
    messagebox._show("Upload", "Are you Sure you want to upload?")

def search_image():
    image_lol_label = Label(image = image_lol)
    image_lol_label.grid(row= 10, column=1, padx=8, pady=15)

title = tkinter.Label(text = "Cyber Search!",bg = "blue")
title.grid(row = 5, column = 1, padx = 10, pady = 10)
title.config(font=("Algerian", 100))

image_source = Entry()
image_source.grid(row = 7,column = 1,padx = 1,pady = 5)
got_image = image_source.get()

image_lol = PhotoImage(got_image)

image_source_search = Button(text = "Image",command = lambda:search_image())
image_source_search.grid(row = 8,column = 1,padx = 10,pady = 10)

Upload = tkinter.Button(text = "Upload",command = lambda: upload_now() )
Upload.grid(row = 6, column = 1, padx = 1, pady = 1)

root.mainloop()

