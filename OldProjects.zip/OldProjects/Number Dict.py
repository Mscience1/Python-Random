x = int(input("Please input a number"))+1
numb_dict = {}
for i in range(0,x):
    numb_dict[i] = i*i
print(numb_dict)

