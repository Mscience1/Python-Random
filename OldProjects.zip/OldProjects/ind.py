def sheri(x, n):
    return (x / n - int(x / n))


for x in range(-100000, 100000,1):
    b = 2 * x
    if (sheri(x, 1) == (sheri(b, 2) / 2)):
        print(sheri(x, 2), sheri(b, 4),"yolo")