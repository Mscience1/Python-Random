name_list = ["Michael","Miki","Abraham","Hayek"]
food_list = ["Cake","Bread","Grapes","Apples"]
age_list = [9,1,19,15,28]
dict_list = dict(zip(name_list,zip(age_list,food_list)))
print(dict_list)