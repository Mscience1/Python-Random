import random

print("Math Game")
turns = int(input("How many puzzles would you like to complete?"))
points = 0


for x in range(0,turns,1):
    int1 = int(random.randrange(0, 10000))
    int2 = int(random.randrange(0, 10000))
    rops = ['+', '-', '*', '/']
    operation = random.choice(rops)
    q = str(int1) + operation + str(int2)
    sum = eval(str(int1) + operation + str(int2))
    print(q)
    answer = input("What is the sum?")
    print(sum)
    if eval(answer) == sum:
        print("Correct")
        points = points+1
        print("points:",points)

print("Game Over","","points:","",points)


