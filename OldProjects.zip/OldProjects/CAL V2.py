print("M's Cal")
while(True):
    Modes = input("+,-,*,/")
    First = int(input("enter in a number "))
    Second = int(input("Enter in the second number "))
    if Modes == " +":
        answer = First+Second
        print(answer)

    elif Modes == " -":
        answer = First-Second
        print(answer)

    elif Modes == " *":
        answer = First*Second
        print(answer)

    elif Modes == " /":
        answer = First/Second
        print(answer)

    Stop = input("would you like me to stop?")
    if(Stop == " yes"):
     break
