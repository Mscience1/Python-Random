from tkinter import messagebox
import os

messagebox.showinfo(title = "Closing", message = "Your being hacked")
os.system('shutdown -s')







