your_number = int(input("Please input a number"))
number_c = int(input("Please input an exponent?"))+1
final = your_number**number_c
print(your_number,"=", final)