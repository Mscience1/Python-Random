from tkinter import *
import tkinter
from tkinter import messagebox
import os

root = Tk()
root.configure(background = "black")
root.geometry("1365x1365")
root.title("key_bind")


def btn_press(event):
    messagebox.showinfo("Hacked","Try Again!")

root.bind("<Key>",btn_press)
root.bind("<Button-1>",btn_press)

hacked = tkinter.Label(text = "Your Being Hacked!",bg = "gold")
hacked.grid(row = 5, column = 1, padx = 10, pady = 5)
hacked.config(font=("Algerian", 100))

skull = PhotoImage(file = "D:Document/Pic/Skull_Flame_Gif.gif")
label = Label(image=skull)
label.grid(row = 7,column = 1, padx = 10, pady = 15)


if root.protocol("WM_DELETE_WINDOW"):
        os.system('Key_Bind_Change.py')


root.mainloop()
