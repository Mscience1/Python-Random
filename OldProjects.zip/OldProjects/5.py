from matplotlib import pyplot as plt

fig = plt.figure()
fig.set_dpi(100)



ax = plt.axes(xlim=(-10, 10), ylim=(-10, 10))
rect = plt.Rectangle((0,-5),5,3,linewidth=1,edgecolor='r',facecolor='r')
patch = plt.Circle([0,-5],1,fc ='b', ec = 'b')
patch2 = plt.Circle([5,-5],1,fc ='b', ec = 'b')


ax.add_patch(rect)
ax.add_patch(patch)
ax.add_patch(patch2)


plt.show()
