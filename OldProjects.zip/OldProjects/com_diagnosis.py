import tkinter
from tkinter import *

#M1 - diagnosis_program

#setup

question_options = ["Are you over the age of 60?","Have you smoked before?",
                    "Have you used drugs before?","Do you have a history of medical problems?",
                    "Do you have a fever?","have you recently been in an accident?","Have you lost your appetite recently?",
                    "Have you been vomiting?","Do you have a headache?","Were you recently sick?"]

#root setup

root = Tk()
root.configure(background = "black")
root.geometry("210x80")
root.title("Diagnosis")

#button function

def btn_press():
    pass


#items

answer = tkinter.Entry()
btn_q = tkinter.Button(text = "Input",command = lambda:btn_press(),bg = "red")
question = tkinter.Label(text = "Null",bg = "red")

#item location

btn_q.grid(row = 6, column = 2, padx = 5, pady = 5)
question.grid(row = 5, column = 1, padx = 10, pady = 5)
answer.grid(row = 6, column = 1, padx = 5, pady = 5)

root.mainloop()
