from tkinter import *
from tkinter import messagebox

root = Tk()
root.configure(background = "black")

def search_eng():
    book_search.get()

    if book_search.get() == "Make":
        root.wm_withdraw()
        messagebox.showinfo("Book Search","Book found... Look for the blinking light")

    elif book_search.get() == "Physics In the 20th Century":
        root.wm_withdraw()
        messagebox.showinfo("Book Search", "Book found... Look for the blinking light")

    else:
        root.wm_withdraw()
        messagebox.showinfo("Book Search","Invalid Input please try again")

book_search = Entry(master = root,bg = "white",width = 25)
book_search.grid(row = 5, column = 1, padx = 10, pady = 5)

btn_search = Button(master = root, text = "Search",command = lambda: search_eng(),bg = "gold",width = 40,height = 15)
btn_search.grid(row = 5, column = 3, padx = 10, pady = 5)


root.mainloop()
