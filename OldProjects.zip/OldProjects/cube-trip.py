from matplotlib import pyplot as plt

n = 0
dn = 1/100

def add():
    plt.plot([0.5-n, 0.5-n], [0.5-n, 0.5+n], 'blue')
    plt.plot([0.5-n,0.5+n], [0.5-n, 0.5-n], 'purple')
    plt.plot([0.5-n, 0.5+n], [0.5+n,0.5+n], 'green')
    plt.plot([0.5+n, 0.5+n], [0.5-n, 0.5+n], 'red')

while (n <= 10):
    add()
    n = n + dn
    dn = dn + 1/100

plt.show()
