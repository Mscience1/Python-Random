Yearnow = int(input("What year is it?"))
leap = 0
normal = 0
while leap <= Yearnow:
    if leap == Yearnow:
        print("its a leap year")
        normal = 1
    leap += 4

if normal == 0:
    print("Not a leap year")
