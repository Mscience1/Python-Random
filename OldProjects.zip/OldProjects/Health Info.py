from tkinter import *
import tkinter

root = Tk()
root.configure(background = "black")

def answer_get():
    answer.get()
    if answer.get() == "8":
        print("yes")

    else:
        print("no")

q_1 = tkinter.Label(text = "On average, how many hours do you sleep per day?")
q_1.pack()

answer = tkinter.Entry()
answer.pack()

btn_input = tkinter.Button(master = root,text = "Enter", command = lambda: answer_get(),bg = "gold")
btn_input.pack()



root.mainloop()
