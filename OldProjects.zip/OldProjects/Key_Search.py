import tkinter
from tkinter import *


root = Tk()
root.configure(background = "black")

key_word = tkinter.Entry()
key_word.pack()

with open("D:/Document/Doc/test_file/test.txt","r") as m_file:
    k = m_file.read().lower()

def commander():
    key_word.get()
    if key_word in k:
       ok =  tkinter.Label(text = k, bg = "navy")
       ok.pack()

    else:
        nah = tkinter.Label(text = "Keyword not found in file", bg = "navy")
        nah.pack()

search_btn = tkinter.Button(text = "Search",command = lambda: commander(),bg = "gold")
search_btn.pack()

root.mainloop()