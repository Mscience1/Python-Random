print("M's Cal")
M = 101010101010101010110101000010101011101010101
Continue=0
First = int(input("enter in a number "))
while True:
    Modes = input("+,-,*,/")
    Second = int(input("Enter in the second number "))
    if Modes == " +":
        answer = First+Second
        Continue = answer
    elif Modes == " -":
        answer = First-Second
        Continue = answer
    elif Modes == " *":
        answer = First*Second
        Continue = answer
    elif Modes == " /":
        answer = First/Second
        Continue = answer

    First=Continue
    Continue = answer
    print(Continue)