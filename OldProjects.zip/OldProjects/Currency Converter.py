print("M's Currency Converter")
GBP = 0
ILS = 0
EUR = 0
USD = 0
JPY = 0
CAD = 0
AUD = 0

print("GBP,ILS,EUR,USD,JPY,CAD,AUD")
Currency1 = input("Please type in a currency from the list above")
Number = float(input("Please input a number"))
Currency2 = input("Please type in the currency that you would like to convert to")
print("result")

if (Currency1 == " GBP" and Currency2 == " ILS"):
    result = Number*4.63497344
    print(result)

if (Currency1 == " ILS" and Currency2 == " GBP"):
    result = Number/4.63497344
    print(result)

if (Currency1 == " GBP" and Currency2 == " USD"):
    result = Number*1.29300
    print(result)

if (Currency1 == " USD" and Currency2 == " GBP"):
    result = Number/1.29300
    print(result)

if (Currency1 == " GBP" and Currency2 == " EUR"):
    result = Number*1.09387624
    print(result)

if (Currency1 == " EUR" and Currency2 == " GBP"):
    result = Number/1.09387624
    print(result)

if (Currency1 == " ILS" and Currency2 == " EUR"):
    result = Number*0.236004856
    print(result)

if (Currency1 == " EUR" and Currency2 == " ILS"):
    result = Number/0.236004856
    print(result)

if (Currency1 == " ILS" and Currency2 == " USD"):
    result = Number*0.278966
    print(result)

if (Currency1 == " USD" and Currency2 == " ILS"):
    result = Number/0.278966
    print(result)

if (Currency1 == " USD" and Currency2 == " EUR"):
    result = Number/1.182035
    print(result)

if (Currency1 == " EUR" and Currency2 == " USD"):
    result = Number*1.182035
    print(result)

if (Currency1 == " JPY" and Currency2 == " USD"):
    result = Number*0.009158
    print(result)

if (Currency1 == " USD" and Currency2 == " JPY"):
    result = Number/0.009158
    print(result)

if (Currency1 == " JPY" and Currency2 == " GBP"):
    result = Number*0.00708275329
    print(result)

if (Currency1 == " GBP" and Currency2 == " JPY"):
    result = Number/0.00708275329
    print(result)

if (Currency1 == " JPY" and Currency2 == " EUR"):
    result = Number*0.00774765553
    print(result)

if (Currency1 == " EUR" and Currency2 == " JPY"):
    result = Number/0.00774765553
    print(result)

if (Currency1 == " JPY" and Currency2 == " ILS"):
    result = Number*0.0328283734
    print(result)

if (Currency1 == " ILS" and Currency2 == " JPY"):
    result = Number/0.0328283734
    print(result)

if (Currency1 == " CAD" and Currency2 == " USD"):
    result = Number*0.780671
    print(result)

if (Currency1 == " USD" and Currency2 == " CAD"):
    result = Number/0.780671
    print(result)

if (Currency1 == " CAD" and Currency2 == " ILS"):
    result = Number*2.79844497
    print(result)

if (Currency1 == " ILS" and Currency2 == " CAD"):
    result = Number/2.79844497
    print(result)

if (Currency1 == " CAD" and Currency2 == " GBP"):
    result = Number*0.603767208
    print(result)

if (Currency1 == " GBP" and Currency2 == " CAD"):
    result = Number/0.603767208
    print(result)

if (Currency1 == " CAD" and Currency2 == " EUR"):
    result = Number*0.660446603
    print(result)

if (Currency1 == " EUR" and Currency2 == " CAD"):
    result = Number/0.660446603
    print(result)

if (Currency1 == " CAD" and Currency2 == " JPY"):
    result = Number*85.2447041
    print(result)

if (Currency1 == " JPY" and Currency2 == " CAD"):
    result = Number/85.2447041
    print(result)

if (Currency1 == " AUD" and Currency2 == " USD"):
    result = Number*0.789455
    print(result)

if (Currency1 == " USD" and Currency2 == " AUD"):
    result = Number/0.789455
    print(result)

if (Currency1 == " AUD" and Currency2 == " GBP"):
    result = Number*0.610560712
    print(result)

if (Currency1 == " GBP" and Currency2 == " AUD"):
    result = Number/0.610560712
    print(result)

if (Currency1 == " AUD" and Currency2 == " ILS"):
    result = Number*2.82993268
    print(result)

if (Currency1 == " ILS" and Currency2 == " AUD"):
    result = Number/2.82993268
    print(result)

if (Currency1 == " AUD" and Currency2 == " EUR"):
    result = Number*0.667877855
    print(result)

if (Currency1 == " EUR" and Currency2 == " AUD"):
    result = Number/0.667877855
    print(result)

if (Currency1 == " AUD" and Currency2 == " CAD"):
    result = Number*1.01125186
    print(result)

if (Currency1 == " CAD" and Currency2 == " AUD"):
    result = Number/1.01125186
    print(result)

if (Currency1 == " AUD" and Currency2 == " JPY"):
    result = Number*86.2038655
    print(result)

if (Currency1 == " JPY" and Currency2 == " AUD"):
    result = Number/86.2038655
    print(result)

