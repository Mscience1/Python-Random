#from mobilechelonian import Turtle
import turtle

tim = turtle.Turtle()

def polygon(n):
    angle = 360/n
    for x in range(0,n,1):
        tim.forward(50)
        tim.left(angle)

polygon(10)

