import turtle
from random import randint
import random

size = 500

screen = turtle.Screen()
screen.title("Miki's Snake Game")
screen.setup(size + 48, size + 48)
screen.bgcolor("black")

food = turtle.Turtle()
food.up()
food.shape("circle")
food.color("red")
food.ht()


def getRandPos():
    return (randint(-size // 2, size // 2), randint(-size // 2, size // 2))


food_coor = getRandPos()

snake = turtle.Turtle()
snake.up()
snake.shape("square")
snake.color("gold")
snake.ht()


snake_squares = [(0, 0)]

stamps = []

dir_x = 0
dir_y = 0

stop = False

def actualise_display():
    tracer = screen.tracer()
    screen.tracer(0)

    food.clearstamps(1)
    snake.clearstamps(len(snake_squares))

    food.goto(food_coor[0], food_coor[1])
    food.stamp()

    for x, y in snake_squares:
        snake.goto(x, y)
        snake.stamp()

    screen.tracer(tracer)


def actualise_pos():
    global snake_squares, food_coor, stop
    avance()
    if self_collision() or border_collision():
        stop = True

    if food_collision():
        append()
        food_coor = getRandPos()

def loop():
    if stop:
        gameOver()
        return
    actualise_pos()
    actualise_display()
    screen.ontimer(loop, 100)


def self_collision():
    global snake_squares
    return len(set(snake_squares)) < len(snake_squares)


def food_collision():
    sx, sy = snake_squares[0]
    fx, fy = food_coor
    distance = ((sx - fx) ** 2 + (sy - fy) ** 2) ** .5
    return distance < 20


def border_collision():
    x, y = snake_squares[0]
    return not (-size // 2 - 50 < x < size // 2 + 50) or not (-size // 2 - 50 < y < size // 2 + 50)

def avance():
    global snake_squares
    x, y = snake_squares[0]
    x += dir_x * 20
    y += dir_y * 20
    snake_squares.insert(0, (x, y))
    snake_squares.pop(-1)


def append():
    global snake_squares
    a = snake_squares[-1][:]
    snake_squares.append(a)


def setDir(x, y):
    global dir_x, dir_y
    dir_x = x
    dir_y = y


def right(): setDir(1, 0)


def left(): setDir(-1, 0)


def up(): setDir(0, 1)


def down(): setDir(0, -1)

def gameOver():
    d = turtle.Turtle()
    d.up()
    d.ht()
    d.color("red")
    d.write("GAME OVER\nScore : %04d" % (len(snake_squares)), align="center", font=("Arial", 30, "bold"))
    screen.onclick(lambda *a: [screen.bye(), exit()])


screen.onkeypress(up, "Up")
screen.onkeypress(down, "Down")
screen.onkeypress(right, "Right")
screen.onkeypress(left, "Left")
screen.listen()
loop()
turtle.mainloop()