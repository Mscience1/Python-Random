import random

b = 1
while(b == 1):

    x = random.randrange(-100, 100)
    d = 2
    v = random.randrange(-100, 100)

    lol = d ** x
    bv = 1 / d ** v

    if lol == bv:
        print(v)
        print(x)
        print(v + x)
        b=2

    else:
        print("")

