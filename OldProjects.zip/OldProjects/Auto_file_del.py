import os

#os.remove(path, *, dir_fd=None)
