#Animation Of Gravity

import matplotlib.pyplot as plt
import matplotlib.animation as animation
import math as mm

#Grav Constant
G = 6.67408e-2

#Sun
sunmass = 1.989e21
px = [0]
py = [0]


#Earth
xl = []
yl = []

#Newtons,Seconds,Kg,Meters,m/s
m = 5.972e15
R = 149.60
F = G*sunmass*m/R**2
t = 0
alpha = 0
a = F / m
v = mm.sqrt(a * R)
omeg = v / R
T = (mm.pi * 2 * R / v)

for i in range(0,600000):
    t2 = t
    t += 1
    alpha = omeg*t
    alpha = alpha*57.2958 - alpha
    vx = v*mm.cos(alpha)
    vy = v*mm.sin(alpha)
    x = vx*(t - t2)
    y = vy*(t - t2)
    xl.append(x)
    yl.append(y)

def basic():
    plt.xlim(min(xl) - 1000, max(xl) + 1000)
    plt.ylim(min(yl) - 1000, max(yl) + 1000)
    plt.title('Earth Orbit', fontsize=20)


fig,ax = plt.subplots()

basic()

plt.scatter(px, py, c='y', s=109)


def animate(i):
#    ax.clear()
    basic()
    sun = plt.scatter(px, py, c='y', s=109)
    earth = ax.scatter(xl[i*60**2], yl[i*60**2], c='g', s=1)

    if (next(ani.frame_seq) > 156):
        ax.clear()
        basic()
        ani.frame_seq = ani.new_frame_seq()

ani = animation.FuncAnimation(fig, animate, interval=100)

plt.show()





