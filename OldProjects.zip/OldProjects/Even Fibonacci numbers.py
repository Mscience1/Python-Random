numb1 = 1
last_numb = 0
before_numb = 0
sum_even = 0

while(numb1 < 4000000):
    before_numb = last_numb
    last_numb = numb1
    numb1 = last_numb+before_numb
    if numb1%2 == 0:
        sum_even = numb1+sum_even

print(sum_even)
