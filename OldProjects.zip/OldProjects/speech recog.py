# Autism - Speech - M9

import os
import speech_recognition as sr
from gtts import gTTS
import wave

angry = ["angry","!"]
sad = ["sad","i hate myself"]
happy = ["happy"]
surprise = ["surprised"]


def speak(audio):
    print(audio)
    tts = gTTS(text = audio, lang = "en")
    tts.save("audio.mp3")
    os.system("audio.mp3")
    os.remove('audio.mp3')


def admin_command():

    r = sr.Recognizer()

    with sr.Microphone() as source:
        print('Waiting for Input...')
        r.pause_threshold = 1
        r.adjust_for_ambient_noise(source, duration=1)
        audio = r.listen(source)

    with open("Speech-results_For_.wav", "wb") as f:
        f.write(audio.get_wav_data())

    try:
        command = r.recognize_google(audio).lower()
        print('You said: ' + command + '\n')


    except sr.UnknownValueError:
        print('Your last command couldn\'t be heard')
        command = admin_command()

    if command in angry:
        speak("He was offended")

    elif command in happy:
        speak("he is happy")

    elif command in sad:
        speak("he is sad")

    elif command in surprise:
        speak("he is surprised")

    elif command == "that is absolute nonsense":
        speak("He is angry")

    elif command == "that's infuriating":
        speak("He is angry")

    elif command == "things just haven't been great lately":
        speak("He is sad")

    elif command == "that's depressing":
        speak("He is sad")

    elif command == "i'm sure":
        speak("He is being sarcastic")

#    spf = wave.open("Speech-results_For_.wav", 'r')

    os.system("j.py")

    return command


while(True):
    admin_command()



