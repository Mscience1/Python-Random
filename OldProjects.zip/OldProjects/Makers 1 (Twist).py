from tkinter import *

root = Tk()
root.configure(background = "black")

def destroy_first_btn():
    physics_search.destroy()
    chem_search.destroy()
    bio_search.destroy()

def chem_eng():
    destroy_first_btn()
    bio_chem = Button(master = root, text = "Biochemistry",command = lambda: biochem_eng(), bg = "silver",width = 20,height = 10 )
    bio_chem.grid(row=5, column=3, padx=10, pady=5)
    nuclear_chem = Button(master = root, text = "Nuclear chemistry", command = lambda: nuclear_chem_eng(), bg = "silver",width = 20,height = 10)
    nuclear_chem.grid(row = 5, column = 1, padx = 10, pady = 5)

def search_eng():
     destroy_first_btn()
     astro = Button(master = root,text = "Astrophysics",command = lambda: astro_eng(),bg = "green",width = 20, height = 10)
     astro.grid(row=5, column=3, padx=10, pady=5)
     applied_phys = Button(master = root,text = "Applied Physics",command = lambda: applied_eng(), bg = "green",width = 20,height = 10 )
     applied_phys.grid(row = 5, column = 1, padx = 10, pady = 5)


def bio_eng():
    destroy_first_btn()
    anatom = Button(master = root,text = "Anatomy", command = lambda: anatomy_eng(), bg = "blue",width = 20, height = 10)
    anatom.grid(row=5, column=3, padx=10, pady=5)
    cell_bio = Button(master = root,text = "Cell biology",command = lambda: cell_eng(),bg = "blue", width = 20, height = 10 )
    cell_bio.grid(row = 5,column = 1, padx = 10, pady = 5)


def astro_eng():
    pass

def biochem_eng():
    pass

def applied_eng():
    pass

def nuclear_chem_eng():
    pass

def anatomy_eng():
    pass

def cell_eng():
    pass


physics_search = Button(master = root, text = "Physics",command = lambda: search_eng(),bg = "gold",width = 40,height = 15)
physics_search.grid(row = 5, column = 3, padx = 10, pady = 5)

chem_search = Button(master = root, text = "Chemistry",command = lambda: chem_eng(),bg = "gold",width = 40,height = 15)
chem_search.grid(row = 5, column = 1, padx = 10, pady = 5)

bio_search = Button(master = root, text = "Biology",command = lambda: bio_eng(),bg = "gold", width = 40,height = 15 )
bio_search.grid(row = 5, column = 5, padx = 10, pady = 5)


root.mainloop()




#M1