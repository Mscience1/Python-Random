from matplotlib import pyplot as plt
from math import pi

fig = plt.figure()
fig.set_dpi(100)

n=0
theta = pi/6
alpha = (2*pi)/34
r = 2

while(n<=34):
    alpha_n = alpha * n
    plt.polar([alpha_n,theta+alpha_n],[r,r],lw = 1 )
    n +=1



plt.show()
