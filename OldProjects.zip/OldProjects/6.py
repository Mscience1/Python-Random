from matplotlib import pyplot as plt
from math import pi


fig = plt.figure()
fig.set_dpi(100)

angle_of_impact = float(input("Input Angle In Radians"))

Impact = plt.polar([angle_of_impact,0,0],[5,5,5],lw = 5 ,c ='b' )
return1 = plt.polar([-angle_of_impact,0,0],[5,5,5],lw = 5 ,c ='b' )
plt.polar([0,0,-pi],[5,5,5],lw = 5 ,c ='r')

plt.show()
