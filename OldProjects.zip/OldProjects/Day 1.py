Year = int(input("When were you born?"))
Yearnow = int(input("What year is it now?"))
age = Yearnow-Year
print("Your age")
print(age)

if(age >= 18 and age <= 130):
    print("Your eligible to vote")

elif(age <= 18):
    print("Your too young to vote")

if(age >= 65 and age <= 130):
    print("Your able to retire")

else:
    print("Please insert a valid number")