#009 - world population change - year 2018

#NOTES
#humans only currently calculated - will be addressed in future update to program
#In a future update AI will run the program - potentialy adding varibales for consideration - chatbot included
#currently using stats from 2018
# water in liters
#economy in U.S. dollars

class human_world:
    def __init__(self,year,birth_rate_per_1000,crude_death_rate_per_1000,population_today,drink_water,global_economy):
        self.year = year
        self.birth_rate_per_1000 = birth_rate_per_1000
        self.crude_death_rate_per_1000 = crude_death_rate_per_1000
        self.population_today = population_today
        self.drink_water = drink_water
        self.global_economy = global_economy

class person:
    def __init__(self,water_cons,death_age,income):
        self.water_cons = water_cons
        self.death_age = death_age
        self.income = income


individual = person(4,71.5,10000)

earth_2018 = human_world(2018,18.6,8.33,7.616*10**9,2142*10**15,77.3 * 10**12)

per_num = 1000

t = earth_2018.year - 1987
N = earth_2018.population_today - 5*10**9
growth_rate = N/t

year_pop = int(input("Please Input Future Year "))

future_t = year_pop - earth_2018.year
future_pop = earth_2018.population_today+future_t*growth_rate

future_water_on_earth = earth_2018.drink_water-individual.water_cons*future_pop
birth_in_future_year = earth_2018.birth_rate_per_1000*future_pop/per_num
crude_death_in_future_year = earth_2018.crude_death_rate_per_1000*future_pop/per_num

if future_water_on_earth <= 0:
    future_water_on_earth = 0


print(year_pop,"Population:",future_pop)
print("Drinkable Water on Earth year",year_pop,":",future_water_on_earth)
print("Birth in Year",year_pop,":",birth_in_future_year)
print("Death in year",year_pop,":",crude_death_in_future_year)
print("growth rate according to Gr = N/t",":",growth_rate)
print("growth rate according to life - death ratio",":",birth_in_future_year-crude_death_in_future_year)
