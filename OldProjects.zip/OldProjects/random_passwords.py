import random
import string

password_options = string.ascii_letters+string.digits+string.ascii_uppercase

def password_genarator():

    choice = input("Weak or Strong Password?")
    strong = random.randint(6, 11)
    weak = random.randint(2, 6)


    if choice == " weak":
        size = weak
        for x in range(0, size):
            password = "".join(random.choice(password_options))
            print(password)

    elif choice == " strong":
        size = strong
        for x in range(0,size):
            password = "".join(random.choice(password_options))
            print(password)


password_genarator()




