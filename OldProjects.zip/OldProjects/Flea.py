import turtle
from math import pi

lis = []

def get_random_list(u,n):

    for x in range(0,n,1):
        new = (pi+u)**5
        u = new%1
        lis.append(u)
    print(lis)
    return lis

tim = turtle.Turtle()

def path(l):
    list = get_random_list(0.3, l)
    for x in range(0,l,1):
        tim.setheading(int(list[x]*360))
        tim.forward(list[x]*100)

path(10)

