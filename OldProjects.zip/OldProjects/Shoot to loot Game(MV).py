import pygame
import time
import tkinter
from tkinter import messagebox
import random

color_dictionary = {
    "white": (255, 255, 255),
    "black": (0, 0, 0),
    "red": (255, 0, 0),
    "green": (0, 255, 0),
    "blue": (0, 0, 255),
    "randy": (random.randint(0,255))
}


class Game:
    def __init__(self, window_width, window_height, window_title, fps):
        pygame.init()
        self.window = pygame.display
        self.surface = self.window.set_mode((window_width, window_height))
        self.window.set_caption(window_title)
        self.fps = fps
        self.clock = pygame.time.Clock()
        self.events = pygame.event
        self.running = True
        self.objects = set()

    def run(self):
        while self.running:
            self.check_events()
            self.surface.fill(color_dictionary["white"])
            for object in self.objects:
                if (isinstance(object,Cannon)):
                    object.check_key_press()
                object.draw(self.surface)
            self.window.update()
            self.clock.tick(self.fps)

    def quit(self):
        pygame.quit()

    def add_object(self, object):
        self.objects.add(object)

    def check_events(self):
        for event in self.events.get():
            if event.type == pygame.QUIT:
                self.running = False


class Rectangle:
    def __init__(self, x, y, width, height, color):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.color = color

    def draw(self, surface):
        pygame.draw.rect(surface, color_dictionary[self.color], (self.x, self.y, self.width, self.height))


class KeyMovable():
    def __init__(self, key_left, key_right, key_up, key_down, speed):
        self.key_left = key_left
        self.key_right = key_right
        self.key_up = key_up
        self.key_down = key_down
        self.speed = speed

    def check_key_press(self):
        keys_pressed = pygame.key.get_pressed()
        if keys_pressed[self.key_left]:
            self.x -= self.speed
        if keys_pressed[self.key_right]:
            self.x += self.speed
        if keys_pressed[self.key_up]:
            self.y -= self.speed
        if keys_pressed[self.key_down]:
            self.y += self.speed

class Cannon(Rectangle, KeyMovable):
    def __init__(self, x, y, width, height, color, key_left, key_right, key_up, key_down, speed):
        Rectangle.__init__(self, x, y, width, height, color)
        KeyMovable.__init__(self, key_left, key_right, key_up, key_down, speed)

    def shoot(self):
        pass

class shoot_stuff():
    def __init__(self, x, y, width, height, color):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.color = color

    def draw(self, surface):
        pygame.draw.rect(surface, color_dictionary[self.color], (self.x, self.y, self.width, self.height))

    def spawn_new(self):
        pass

game = Game(1200,600, "Shoot 2 Loot", 60)

time.sleep(3)

rec1 = (Rectangle(0,0,1200,5,"black"))
rec2 = (Rectangle(0,595,1200,5,"black"))
game.add_object(rec1)
game.add_object(rec2)
rec3 = (Rectangle(0,0,5,1290,"black"))
rec4 = (Rectangle(1199.99,0,5,1270,"black"))
game.add_object(rec4)
game.add_object(rec3)
Player1_Cann = Cannon(600,560,30,30,"randy",pygame.K_LEFT,pygame.K_RIGHT,pygame.K_UP,pygame.K_DOWN,5)
game.add_object(Player1_Cann)
shoot_rec1 = shoot_stuff(400,30,100,80,"red")
game.add_object(shoot_rec1)x


game.run()

game.quit()
