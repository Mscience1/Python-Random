import matplotlib.pyplot as plt

def pascal(n):

    length = 11**n
    length = [int(m) for m in str(length)]
    list_numb = [[0 for i in range(len(length*2))] for k in range(len(length))]

    for x in range(n+1):
        list_numb[x][n - x] = 1
        list_numb[x][n + x] = 1
        if not x == 0:
            for k in range(1,n*2):
                list_numb[x][k] = list_numb[x-1][k+1]+list_numb[x-1][k-1]
    return (list_numb)

pascal_call = pascal(5)

for line in pascal_call:
    print(line)

plt.imshow(pascal_call)
plt.show()
