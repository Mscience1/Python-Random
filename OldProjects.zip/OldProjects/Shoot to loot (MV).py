from tkinter import *

root = Tk()
root.configure(background = "black")

title_input = Entry(master = root,bg = "silver",width = 15)

def game_search():
    pass

start_btn = Button(master = root,text = "Input Title of game",command = lambda: game_search())


title_input.grid(row = 5,column = 1,padx=10, pady=5)
start_btn.grid(row = 5,column = 2,padx=10, pady=5)

root.mainloop()


