#Miki - Googol

googol = 10**100

print(googol)

