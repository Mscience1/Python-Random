from matplotlib import pyplot as plt

fig = plt.figure()
fig.set_dpi(100)
fig.set_size_inches(5,5)

ax = plt.axes(xlim=(-4, 4), ylim=(-4, 4))
ax.set_aspect('equal')
patch = plt.Polygon([[-2,-2],[-2,2],[2,2],[2,-2],[-2,-2]] ,lw = 4, ec = 'g', fc = 'r')
ax.add_patch(patch)
plt.show()
