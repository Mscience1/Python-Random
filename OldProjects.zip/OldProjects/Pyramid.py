Layers = int(input("How many layers do you want?"))
CO = "."
for NoLayers in range (0,Layers,1):
    print(CO)
    CO += "."