import random
from random import randrange
from tkinter import messagebox

#Card Game - M1

#list
rank_list = [2,3,4,5,6,7,8,9,10,11,12,13,14,15]
name_list = ["Two","Three","Four","Five","Six","Seven","Eight","Nine","Ten","Jake","Queen","King","Ace","Joker"]
color_dict = {"black" : (0, 0, 0),"red" : (255, 0, 0)}

#Type
class Cards:
   def __init__(self,name,rank,color):
    self.name = name
    self.rank = rank
    self.color = color

   def Spawn(self):
       print(self.name,self.rank,self.color)

class Player:
    def __init__(self,name,numb_card):
        self.name = name
        self.numb_card = numb_card


#Spawn Example
Jake = Cards(name_list[9],rank_list[9],color_dict["black"])
Jake_Red = Cards(name_list[9],rank_list[9],color_dict["red"])
Two = Cards(name_list[0],rank_list[0],color_dict["black"])
Two_Red = Cards(name_list[0],rank_list[0],color_dict["red"])
Ten_Red = Cards(name_list[8],rank_list[8],color_dict["red"])
Ten = Cards(name_list[8],rank_list[8],color_dict["black"])


player_1 = Player("Player 1",2)
player_2 = Player("Player 2",2)

Player_One_list = [Two_Red,Jake,Ten_Red]
Player_Two_list = [Jake_Red,Two,Ten]

Player_One_Points = 0
Player_Two_Points = 0
turns = 10

#Run
begin = input("Would You Like to play?")

#Game Start
if begin == " yes":
        print("Great")
        print(".....")
        for x in range(0,5,1):
            random_index = randrange(0, len(Player_One_list))
            random_index_2 = randrange(0, len(Player_Two_list))
            print(player_1.name)
            Player_One_list[randrange(0,len(Player_Two_list))].Spawn()
            print("------")
            print(player_2.name)
            Player_Two_list[randrange(0,len(Player_Two_list))].Spawn()
            print("------")

            if Player_One_list[random_index].rank > Player_Two_list[random_index_2].rank:
                Player_One_Points += 1

            elif Player_One_list[random_index].rank < Player_Two_list[random_index_2].rank:
                Player_Two_Points += 1


#Game Won
if Player_One_Points > Player_Two_Points:
    print("One :",Player_One_Points,"Two :",Player_Two_Points)
    messagebox.showinfo("Game Over","Player 1 won")

elif Player_One_Points < Player_Two_Points:
    print("One :", Player_One_Points, "Two :", Player_Two_Points)
    messagebox.showinfo("Game Over","Player 2 won")

else:
    print("One :", Player_One_Points, "Two :", Player_Two_Points)

