import matplotlib.pyplot as plt

m1 = 0.5
a = []
m = []
T = 5

for m2 in range(1,1000):
    m.append(1/m2)
    a.append(T/m2)

print((a[3]-a[2])/(m[3]-m[2]))
plt.plot(m,a)
plt.xlabel("1/m (kg)")
plt.ylabel("a (m/s**2)")

plt.show()

