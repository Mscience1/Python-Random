import matplotlib.pyplot as plt
import matplotlib.animation as animation
import math as mm

#water_viscocity
wa = 8.90*10**-4

#radius of ball
r = 1.2 * 10**-2

# ball mass
m = 28.42*10**-3

# g = grav const on earth

g = 9.81
v = [0]
a = [g]
x = [0]
y = [0]
t = 0
tt = [0]
Fg = m*g
Bob = 1


while(Bob == 1):
        t2 = t
        t+=1
        x.append( x[t-1] + v[t-1])
        v.append( v[t-1] + a[t-1]*(t-t2))
        Fd = 6*mm.pi*wa*r*v[t]
        a.append((Fg-Fd)/m)
        y.append(0)
        tt.append(t)


        if((Fg -Fd) < 10**-3):
            Bob = 2



def basic():
    plt.title('Terminal Velocity a - t', fontsize=20)



fig, ax = plt.subplots()

basic()

plt.plot(tt,x)

plt.show()




