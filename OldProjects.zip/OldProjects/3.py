from matplotlib import pyplot as plt

fig = plt.figure()
fig.set_dpi(100)

ax = plt.axes(xlim=(-10, 10), ylim=(-10, 10))
patch1 = plt.Polygon([[0,0],[0,5],[4.33,2.5]],lw = 4, ec = 'b', fc = 'b')
patch2 = plt.Polygon([[3,0],[3,5],[-1.33,2.5]],lw = 4, ec = 'b', fc = 'b')
ax.add_patch(patch1)
ax.add_patch(patch2)


plt.show()
