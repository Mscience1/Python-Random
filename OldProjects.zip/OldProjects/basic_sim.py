#Circular Motion Basic Sim

import matplotlib.pyplot as plt
import math as mm

xl = []
yl = []

#Newtons,Seconds,Kg,Meters,m/s
F = 6
t = 0
m = 2
R = 2
alpha = 0
a = F / m
v = mm.sqrt(a * R)
omeg = v / R
T = mm.pi * 2 * omeg


while (t<5*T):
    t2 = t
    t += 1
    alpha = omeg*t
    alpha = alpha*57.2958 - alpha
    vx = v*mm.cos(alpha)
    vy = v*mm.sin(alpha)
    x = vx*(t - t2)
    y = vy*(t - t2)
    xl.append(x)
    yl.append(y)


plt.plot(xl,yl)
plt.show()

