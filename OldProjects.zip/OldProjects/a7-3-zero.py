def zeroes(m,n):
   for i in range(0,m,1):
       l = [0]*n
       print(l)


zeroes(5,5)
