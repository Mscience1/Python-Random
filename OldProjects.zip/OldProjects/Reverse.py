string = str(input("Which word would you like me to reverse?"))
reverse_string = string[::-1]
print(reverse_string)

if string == reverse_string:
    print("")
    print("pali")

else:
    print("Not a pali")


