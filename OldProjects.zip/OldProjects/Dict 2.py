tuple_country1 = ('Engalnd','France','Israel')
tuple_city1 = {'London','Paris','Tel-Aviv'}
dict_city_country = dict(zip(tuple_country1,zip(tuple_city1)))
print(dict_city_country)