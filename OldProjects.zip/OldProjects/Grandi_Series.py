#Miki Grandi_Series - telescoping series method

n = 0

while(True):
    s = (-1) ** n
    s = s - s
    n = n+1
    print(s)

