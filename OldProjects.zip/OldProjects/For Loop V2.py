while(True):
    print("Hello")
    W = input("Would you like to continue?")
    if W==" no":
        break

