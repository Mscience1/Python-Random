#Miki - Euler's Number - e

n = 0

while(True):
    n = n+1
    e = (1+1/n)**n
    print(e)




