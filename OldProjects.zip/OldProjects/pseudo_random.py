from math import pi

lis = []

def get_random_list(u,n):

    for x in range(0,n,1):
        new = (pi+u)**5
        u = new%1
        lis.append(u)
    print(lis)

get_random_list(0.3,5)


