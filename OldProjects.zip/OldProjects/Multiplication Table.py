your_number = int(input("Please input a number"))
number_c = int(input("How many times would you like me to run?"))+1
for mult in range(0,number_c):
    final = your_number*mult
    print(your_number,"*",mult,"=", final)