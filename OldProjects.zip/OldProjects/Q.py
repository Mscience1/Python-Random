import discord
import os
from chatterbot import ChatBot
from chatterbot.trainers import ListTrainer
import wikipedia
from discord.utils import get

Q_talk = ChatBot('Q')
Q_talk.set_trainer(ListTrainer)

for files in os.listdir('D:\Document\Doc\Q\chatterbot-corpus-master\chatterbot_corpus\data\english'):
    data = open('D:\Document\Doc\Q\chatterbot-corpus-master\chatterbot_corpus\data\english/' + files ,'r',errors='ignore').readlines()
    Q_talk.train(data)

client = discord.Client()

@client.event
async def on_ready():
    print("The bot is awake!")
    await client.change_presence(game=discord.Game(name="Making a    bot"))

@client.event
async def on_message(message):
    if message.author == client.user:
        return

    lol = message.content
    reply = Q_talk.get_response(lol)

    if lol.startswith("!wiki"):
        reply = wikipedia.summary(message.content[3:], sentences=2)

    elif lol.startswith("!gnome"):
        reply = "https://www.youtube.com/watch?v=6n3pFFPSlW4"
        role = get(message.server.roles, name='ADMIN')
        await client.add_roles(message.author, role)
        await client.delete_message(message)

    elif lol.startswith("!mega"):
        reply = "https://www.youtube.com/watch?v=6n3pFFPSlW4"
        role = get(message.server.roles, name='megaman')
        await client.add_roles(message.author, role)
        await client.delete_message(message)

    elif lol.startswith("!spam"):
        reply = "https://www.youtube.com/watch?v=6n3pFFPSlW4"
        role = get(message.server.roles, name='spammr')
        await client.add_roles(message.author, role)
        await client.delete_message(message)

    await client.send_message(message.channel,reply, tts = True)

client.run('NDk5ODg3NzI3NTY3ODMxMDUx.DqEMsQ.MTcrMVqXp36qTsXJYxHq0oXqjdI')
