def fibo_seq(n):
    list = [1]
    for x in range(0,n,1):
        numb =  list[x] + list[x-1]
        list.append(numb)

    del list[1]
    print(list)

fibo_seq(15)

