planet_list = ["Mercury","Venus","Earth","Mars","Jupiter","Saturn","Uranus","Neptune","Planet Nine"]

e_moon_list = ["Luna"]

m_moon_list = ["Phobos","Deimos"]

u_moon_list = ["Cordelia","Ophelia","Bianca","Cressida","Desdemona","Juliet","Portia","Rosalind","Cupid","Belinda","Perdita","Puck","Mab","Miranda","Ariel","Umbriel","Titania","Oberon","Francisco","Caliban","Stephano","Trinculo","Sycorax","Margaret","Prospero","Setebos","Ferdinand"]

s_moon_list = ["Pan","Daphnis","Atlas","Prometheus","Pandora","Epimetheus","Janus","Aegaeon","Mimas","Methone","Anthe","Pallene","Enceladus","Tethys","Telesto",
"Calypso","Dione","Helene","Polydeuces","Rhea","Titan","Hyperion","Iapetus","Kiviuq","Ijiraq","Phoebe","Paaliaq","Skathi","Albiorix","S/2007 S 2",
"Bebhionn","Erriapo","Skoll","Siarnaq","Tarqeq","S/2004 S 13","Greip","Hyrrokkin","Jarnsaxa","Tarvos","Mundilfari","S/2006 S 1","S/2004 S 17",
"Bergelmir","Narvi","Suttungr","Hati","S/2004 S 12","Farbauti","Thrymr","Aegir","S/2007 S 3","Bestla","S/2004 S 7","S/2006 S 3","Fenrir",
"Surtur","Kari","Ymir","Loge","Fornjot"]

j_moon_list = ["Adrastea","Amalthea","Thebe","Io","Europa","Ganymede","Callisto","Themisto","Leda","Himalia","Lysithea","Elara","Dia","Carpo","S/2003 J 12","Euporie","	S/2003 J 3","S/2003 J 18","Thelxinoe","Euanthe","Helike","Orthosie","Iocaste","S/2003 J 16","Praxidike","Harpalyke","Mneme","Hermippe","Thyone","Ananke","Herse","Aitne","Kale","Taygete","S/2003 J 19","Chaldene","S/2003 J 15","S/2003 J 10","S/2003 J 23","Erinome","Aoede","Kallichore","Kalyke","Carme","Callirrhoe","Eurydome","Pasithee","Kore","Cyllene","Eukelade","S/2003 J 4","Pasiphaë","Hegemone","Arche","Isonoe","S/2003 J 9","S/2003 J 5","Sinope","Sponde","Autonoe","Megaclite","S/2003 J 2"]

n_moon_list = ["Naiad","Thalassa","Despina","Galatea","Larissa","S/2004 N 1","Proteus","Triton","Nereid","Halimede","Sao","Laomedeia","Psamathe","Neso"]








