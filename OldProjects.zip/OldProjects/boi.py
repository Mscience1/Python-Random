import matplotlib.pyplot as plt

m1 = 0.5
a = []
m = []

for m2 in range(1,1000):
    m.append(1/(m2+m1))
    a.append((m2*9.81)/(m1+m2))

print((a[3]-a[2])/(m[3]-m[2]))
plt.plot(m,a)
plt.xlabel("m (kg)")
plt.ylabel("a (m/s**2)")

plt.show()

