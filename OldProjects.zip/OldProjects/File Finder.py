Note = open('D:/Document/Desktop/Python test/ABC.txt')
print (Note.read())