#M9 - Chatbot(Basic Version)

import random

AI_questions = []
AI_answers = []

w = 1

while(w==1):
    for x in range(0,10,1):

        question1 = input("Question1:")
        AI_questions.append(question1)

        answer1 = input("Answer2:")
        AI_answers.append(answer1)

        question2 = input("Question2:")
        AI_questions.append(question2)

        answer2 = input("Answer1:")
        AI_answers.append(answer2)

        cont = input("Would you like to continue this conversation with a person or an AI?")

        if cont == "AI":
            w = 2
            print("")
            print("")
            print("")
            print("")
            print("")
            print("")
            print("")
            print("")
            print("")
            print("")
            print("")
            print("AI Possible Questions:",AI_questions)
            print("AI Possible Answers:",AI_answers)
            print("")
            print("AI:",AI_questions[0])
            player_a = input("NameA:")
            player_q = input("NameQ:")

            if player_q in AI_questions:
                    print("AI:",AI_answers[random.randrange(0,len(AI_answers))])
                    print("AI Q:",AI_questions[random.randrange(0,len(AI_questions))])




