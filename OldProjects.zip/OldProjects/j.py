import numpy as np
import matplotlib.pyplot as plt
import scipy.io.wavfile as wf

fs, signal = wf.read("Speech-results_For_.wav")   # Load the file
signal = signal * 1.0 / 32768                     # Scale the signal in [-1, 1]

N = 8192
win = np.hamming(N)
x = signal[0:N] * win                             # Take a slice and multiply by a window

sp = np.fft.rfft(x)                               # Calculate real FFT

mag = np.abs(sp)
ref = np.sum(win) / 2                             # Reference : window sum and factor of 2
                                                  # because we are using half of FFT spectrum

s_dbfs = 20 * np.log10(mag / ref)                 # Convert to dBFS

freq = np.arange((N / 2) + 1) / (float(N) / fs)   # Frequency axis
plt.plot(freq, s_dbfs)
plt.grid(True)
plt.xlabel('Frequency [Hz]')
plt.ylabel('Amplitude [dB]')
plt.show()
