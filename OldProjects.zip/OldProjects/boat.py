import turtle

yolo = 10E-4

i=1


win = turtle.Screen()

img = "D:\Document\Pic\gat.gif"

img2 = "D:\Document\Pic/loader.gif"

win.addshape(img)
win.addshape(img2)

boat = turtle.Turtle()
boat.shape(img)
boat.shapesize(1,1,1)
boat.up()
boat.goto(-600, 200)
boat.speed(1)
boat.pendown()

rocket = turtle.Turtle()
rocket.shape(img2)
rocket.shapesize(1,1,1)
rocket.up()
rocket.goto(-600,-300)
rocket.speed(1)
rocket.pendown()


while(i==1):
    rocket.setheading(rocket.towards(boat))
    boat.forward(5.5) #ms**-1
    rocket.forward(13.8) #ms**-1
    if (boat.xcor()-rocket.xcor()<yolo):
        print("Boom!")
        print("x:",boat.xcor(),"y:",boat.ycor())
        print("Time","43 Seconds")
        i = 2


win.exitonclick()
