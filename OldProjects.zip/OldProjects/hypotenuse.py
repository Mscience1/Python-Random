def hypotenuse_slope(f,x1,x2):
    x1, x2 = min(x1, x2), max(x1, x2)
    return (f(x2) - f(x1))/(x2 - x1)

def get_linear_function(x1,a, y):
    return -a * x1 + y

def func(f,x1,x2):
    a = hypotenuse_slope(f,x1,x2)
    y = f(x1)
    b = get_linear_function(x1,a,y)
    print("Function: y = ",a,"x+",b )

func(lambda x: 3*x**2 - 4*x,3,4 )