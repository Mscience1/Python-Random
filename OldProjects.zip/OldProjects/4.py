from matplotlib import pyplot as plt

fig = plt.figure()
fig.set_dpi(100)

ax = plt.axes(xlim=(-10, 10), ylim=(-10, 10))
patch1 = plt.Polygon([[0,0],[5,0],[2.5,4.333]],lw = 4, ec = 'b', fc = 'b')
rect = plt.Rectangle((0,-5),5,5,linewidth=1,edgecolor='r',facecolor='r')
door = plt.Rectangle((2,-5),1,2,linewidth=1,edgecolor='b',facecolor='y')


ax.add_patch(rect)
ax.add_patch(patch1)
ax.add_patch(door)


plt.show()
