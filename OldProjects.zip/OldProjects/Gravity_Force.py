#Circular Motion - With Grav Force Sim

import matplotlib.pyplot as plt
import math as mm

#Grav Constant
G = 6.67408e-11

#Sun
sunmass = 1.989e30
px = [0]
py = [0]


#Earth
xl = []
yl = []

#Newtons,Seconds,Kg,Meters,m/s
m = 5.972e24
R = 149.60e9
F = G*sunmass*m/R**2
t = 0
alpha = 0
a = F / m
v = mm.sqrt(a * R)
omeg = v / R
T = mm.pi * 2 * omeg

for i in range(0,600000):
    t2 = t
    t += 1
    alpha = omeg*t
    alpha = alpha*57.2958 - alpha
    vx = v*mm.cos(alpha)
    vy = v*mm.sin(alpha)
    x = vx*(t - t2)
    y = vy*(t - t2)
    xl.append(x)
    yl.append(y)

plt.scatter(xl,yl, c = 'b', s = 1)
plt.scatter(px,py, c = 'y', s = 109)
plt.show()

