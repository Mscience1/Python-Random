from tkinter import *
import tkinter


root = Tk()
root.configure(background = "black")

def answer_get():
    answer.get()
    if answer.get() == "yes":
        print("yes")

    elif answer.get() == "no":
        print("no")

    else:
        print("Entry is empty")

q_1 = tkinter.Label(text = "Yes or No?")
q_1.pack()

answer = tkinter.Entry()
answer.pack()

btn_input = tkinter.Button(master = root,text = "Enter", command = lambda: answer_get(),bg = "gold")
btn_input.pack()



root.mainloop()
