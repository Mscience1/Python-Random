import tkinter
from tkinter import *

eng_numb = {'m':'1','k':'9','d':'12','g':'7','i':'2','c':'10','h':'15','e':'17','a':'21','l':'20','o':'70','r':'5','s':'6','b':'22',
            'n':'18','v':'65','p':'99','x':'97','z':'101','q':'34','f':'28','j':'3','w':'11','t':'55','u':'0','y':'00'}

root = Tk()
root.configure(background = "black")
root.geometry("260x80")
root.title("Decoder")

decode_entry = tkinter.Entry()
decode_entry.grid(row = 6, column = 1, padx = 5, pady = 5)

def btn_press():
    decode_got = decode_entry.get()
    if decode_got in eng_numb.values():
        eng_numb_switched = dict(zip(eng_numb.values(), eng_numb.keys()))
        print(eng_numb_switched[decode_got])
        decode_entry.delete(0, 'end')

decoded_txt = tkinter.Label(text = "Decoder",bg = "red")
decoded_txt.grid(row = 5, column = 1, padx = 10, pady = 5)
decoded_txt.config(font=("Algerian", 10))

decode_btn = tkinter.Button(text = "Decode", command = lambda:btn_press(), bg = "red")
decode_btn.grid(row = 6, column = 2, padx = 5, pady = 5)

root.bind("<Return>",lambda i: btn_press())

root.mainloop()

