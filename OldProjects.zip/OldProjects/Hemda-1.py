import math

#Q2

def get_celinder_volume():
    r = float(input("Input Radius"))
    h = float(input("Input Height"))
    print(r ** 2 * math.pi * h)


get_celinder_volume()

#Q3

def get_celinder_mass():
    d = float(input("Input Density"))
    h = float(input("Input Height"))
    c= float(input("Input Circumference"))
    mass = d*((c/2)**2 * math.pi * h)
    print(mass)

get_celinder_mass()

#Q4(1)

def celsiuse_to_fahrenheit():
    c = float(input("Input Celsiuse"))
    fahrenheit = (9/5)*c+32
    print(fahrenheit)

celsiuse_to_fahrenheit()

#Q4(2)

def fahrenheit_to_celsiuse():
    f = float(input("Input fahrenheit"))
    celsiuse =  f/(9/5) - 32
    print(celsiuse)

celsiuse_to_fahrenheit()

#Q5

def money_growth():
    A = float(input("Input Fund"))
    p =  float(input("Input Percentage Growth"))
    n =  float(input("Input Years"))
    print(A*(1+p/100)**n)

money_growth()

#Q6(1)

g = 9.8

def free_fall_velocity():
    t = float(input("Input Time"))
    velocity = g*t
    print(velocity)

free_fall_velocity()

#Q6(2)

def free_fall_distance():
    t = float(input("Input Time"))
    distance = 0.5*g*t**2
    print(distance)

free_fall_distance()

#Q8

print("  *\n ***\n*****\n  *\n  *\n  *\n  *\n  *")
