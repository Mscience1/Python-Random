sen_words = 'My name is Michael and I am currently learning how to use python'.split()
