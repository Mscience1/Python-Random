Float1 = input("Please type in a decimal number")
Float2 = input("Please type in an additional decimal number")
Float3 = input("Please type in a third decimal number")

if (Float1>Float2 and Float1>Float3):
    print("Biggest number", Float1)

elif (Float2>Float1 and Float2>Float3):
    print("Biggest number", Float2)



elif (Float3>Float1 and Float3>Float2):
    print("Biggest number", Float3)

