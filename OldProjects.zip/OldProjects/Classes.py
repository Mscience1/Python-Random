class Humans:
    curious = "Very curious"

    def howCurious(self):
        return self.curious

class Michael(Humans):
    def howCurious(self):
        return self.curious

class Miki(Michael):
    def howCurious(self):
        return self.curious
class Abraham(Miki):
    def howCurious(self):
        return self.curious
class M(Abraham):
    def howCurious(self):
        return self.curious

Letter1 = M
print(Letter1.curious)

