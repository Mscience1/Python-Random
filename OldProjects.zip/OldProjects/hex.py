#from mobilechelonian import Turtle
import turtle

tim = turtle.Turtle()


def side(color):
    tim.pencolor(color)
    tim.forward(50)
    tim.left(60)


side("blue")
side("red")
side("yellow")
side("green")
side("black")
side("purple")