print("M's Quiz")
points = 0
def correctM():
    print("Correct")

Q1 = input("Galileo was an Italian astronomer who...")
if(Q1 == " developed the telescope"):
    correctM()
    points+= int(1)
else:
    print("False, developed the telescope")

Q2 = input("For the Olympics and World Tournaments, the dimensions of basketball court are...")
if(Q2 == " 28m x 15m"):
     correctM()
     points += 1
else:
    print("False")
Q3 = input("During World War II, when did Germany attack France?")
if(Q3 == " 1940"):
    correctM()
    points += 1
else:
    print("False,1940")

Q4 = input("Einstein is best known by the general public for his mass–energy equivalence formula")
if(Q4 == " E=MC^2"):
    correctM()
    points += 1
else:
    print("False,E=MC^2")

Q5 = input("SpaceX was founded in...")
if(Q5==" 2002"):
    correctM()
    points += 1
    print("points")
    print(points)
    if(points==3):
        print("Not bad")
    elif(points<3):
        print("LOL, your terrible")
    elif(points>4):
        print("Good Job")

    elif(points==5):
        print("Your a genius")

    elif(points==5):
        print("Your a genius")

else:
    print("False,2002")
    print("points")
    print(points)
    if(points==3):
        print("Not bad")
    elif(points<3):
        print("LOL, your terrible")
    elif(points>4):
        print("Good Job")

    elif(points==5):
        print("Your a genius")
