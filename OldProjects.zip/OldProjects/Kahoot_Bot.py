#Miki Bot Code

from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
import random


print("Kahoot spammer v 1.4.4")
pin = input("Please enter a game pin:")
name = input("Please enter a name:")
join = input("Please enter a amount of bots to join(Default is 50):")
tab = 0
nameb = str(name)
bot_num = 0

path = 'D:\chromedriver_win321\chromedriver.exe'
print("Starting chrome...")
chrome_options = Options()
chrome_options.add_argument("--headless")
driver = webdriver.Chrome(path,chrome_options=chrome_options)

if join=='':
    join=50
def namec():
    global join, bot_num, nameb
    num=random.randint(1,999)*3
    if join=='1':
        nameb=name
        bot_num = bot_num + 1
    if int(join)>=2:
        if bot_num==join:
            print("Name generation completed")
        nameb=(name + '.' + str(num))
        bot_num = bot_num + 1
def bot():
    global nameb, driver, tab
    if bot_num==1:
        print("No new window necessary")
    elif bot_num >=2:
        print("Opening new window...")
        driver.execute_script("window.open('');")
        driver.switch_to.window(driver.window_handles[tab])
    print("Navigating to Kahoot...")

    driver.get("https://kahoot.it/")

    wait = WebDriverWait(driver, 10)
    element = wait.until(EC.element_to_be_clickable((By.ID, 'inputSession')))

    inputb = driver.find_element_by_id('inputSession')
    print("Joining game...")

    inputb.send_keys(pin)
    inputb.submit()

    element = wait.until(EC.element_to_be_clickable((By.ID, 'username')))
    gname = driver.find_element_by_id('username')
    namec()
    gname.send_keys(nameb)
    gname.submit()

    print("Checking if login was succesfull...")
    try:
       content = driver.find_element_by_class_name('ng-binding')
    except:
        print("Error checking page:\nId could have changed, or connection could have dropped.")
        x=input("Press any key to exit...")
    print("Success!")
    print("Bot [" + bot_num + "] is now in the game ;)")
    tab = tab + 1

for x in range(int(join)):
    bot()
