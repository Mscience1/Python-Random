import random
randy = random.randint
random_numbers = [randy(0,100),randy(0,100),randy(0,100),randy(0,100),randy(0,100),randy(0,100),randy(0,100),randy(0,100)]
random_numbers_exit = []
for rand in random_numbers:
    rand = rand*3
    rand += 15
    random_numbers_exit.append(rand)
print(random_numbers[0])
print("Is now")
print(random_numbers_exit[0])
print("---")
print(random_numbers[1])
print("Is now")
print(random_numbers_exit[1])
print("---")
print(random_numbers[2])
print("Is now")
print(random_numbers_exit[2])
print("---")
print(random_numbers[3])
print("Is now")
print(random_numbers_exit[3])
print("---")
print(random_numbers[4])
print("Is now")
print(random_numbers_exit[4])
print("---")
print(random_numbers[5])
print("Is now")
print(random_numbers_exit[5])
print("---")
print(random_numbers[6])
print("Is now")
print(random_numbers_exit[6])

