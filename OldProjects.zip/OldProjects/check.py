import random

x = [2,4,6,8]

a = x[random.randrange(len(x))]
b = x[random.randrange(len(x))]
c = x[random.randrange(len(x))]

if ((((a*b)%10)*c)%10 == a*((b*c)%10)%10):
    print((((a*b)%10)*c)%10)
    print(a*((b*c)%10)%10)
    print("kibot")

if(((a*b)%10 == a) and ((b*a)%10) == a):
    print("nat")
    print(a)
    print(b)
    print(c)
else:
    print("jk")
    print(a)
    print(b)

