import matplotlib.pyplot as plt
import matplotlib.animation as animation
import math as m
import random

class Particle():
    def __init__(self,x,y,v,mass,radius):
        self.x = x
        self.y = y
        self.v = v
        self.vx = v*m.cos(m.pi)
        self.vy = v*m.sin(m.pi)*0
        self.mass = mass
        self.radius = radius

p1 = Particle(10,10,5,2,1)
p2 = Particle(-10,10,-5,2,1)


def collision(p1, p2):
    vx1 = p1.vx
    vy1 = p1.vy
    p1.vx = (((p1.mass - p2.mass) / (p1.mass + p2.mass)) * p1.vx + ((2 * p2.mass / (p1.mass + p2.mass)) * p2.vx))
    p1.vy = (((p1.mass - p2.mass) / (p1.mass + p2.mass)) * p1.vy + ((2 * p2.mass / (p1.mass + p2.mass)) * p1.vy))
    p2.vx = (((p2.mass - p1.mass) / (p2.mass + p1.mass)) * p2.vx + ((2 * p1.mass / (p2.mass + p1.mass)) * vx1))
    p2.vy = (((p2.mass - p1.mass) / (p2.mass + p1.mass)) * p2.vy + ((2 * p1.mass / (p2.mass + p1.mass)) * vy1))

x1 = []
x2 = []
y1 = []
y2 = []

for x in range(0,100):

    x1.append(p1.x)
    x2.append(p2.x)
    y1.append(p1.y)
    y2.append(p2.y)

    if (p1.x-p2.x) < 10E-11 and (p1.y-p2.y) < 10E-11:
        collision(p1,p2)
        print("Collision")

    p1.x = p1.vx + p1.x
    p2.x = p2.x + p2.vx
    p1.y = p1.vy + p1.y
    p2.y = p2.y + p2.vy

def basic():
    plt.title('Elastic Collision', fontsize=20)
    plt.xlim(-10,10)
    plt.ylim(5,15)

fig,ax = plt.subplots()

basic()


def animate(i):
    ax.clear()
    basic()
    p1g = plt.scatter(x1[i], y1[i], c='y', s=10)
    p2g = ax.scatter(x2[i], y2[i], c='g', s=10)


ani = animation.FuncAnimation(fig, animate, interval=100)

plt.show()
