import math

#v = m/s
#t = s
#h = m


t = 0
h = 500
vp = 13.8889
vb = 5.55556

for x in range(0,10,1):
    opp = 5.55556 * t
    aja = 500
    result = 13.8889 * t
    