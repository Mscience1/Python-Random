from math import sqrt

def root(start, stop, step):
    l=[]
    n = start
    i = 0

    while (i == 0):

        if (n >= start and n < stop):
            r = sqrt(n)
            l.append(r)
            print("number:",n,"root:",r)

        else:
            i = 1
            print("")
            print("Length of List",len(l))
            print("")
            print("Sum of List",sum(l))

        n = n + step



root(1, 1000, 1)
