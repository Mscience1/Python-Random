import os

for dirpath, dirname, filename in os.walk('D:\Document'):
    print("Path:",dirpath)
    print('Name:',dirname)
    print('FileN',filename)


