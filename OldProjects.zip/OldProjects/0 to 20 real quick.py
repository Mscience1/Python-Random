import random
number = random.randint(1,20)
ask_number = int(input("Please guess a number between 1-20"))

if (ask_number == number):
    print("Your a genius!")

elif (ask_number > number):
    print("Your Number is greater than mine, you lost my number was",number)

elif (ask_number < number):
    print("Your Number is smaller than mine, you lost my number was",number)