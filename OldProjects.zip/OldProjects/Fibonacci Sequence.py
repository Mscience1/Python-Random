#Miki Fibonacci Sequence

Fibonacci_list = [1]

while(True):
    n = len(Fibonacci_list)
    x = Fibonacci_list[n - 1] + Fibonacci_list[n - 2]
    Fibonacci_list.append(x)
    print(x)
