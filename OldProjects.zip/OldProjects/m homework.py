import numpy

tk1 = 40
i2 = 60
for x in numpy.arange(0, 5.26, 0.01):
    v = tk1*x
    f = i2*(x-0.5)
    l = i2*(x-0.5-0.25)

    if (v == f):
        print(v)
        print(f)
        print(x)
        print("")

    else:
        pass

    if (l==v):
        print(v)
        print(l)
        print(f)
        print(x)
        print("")

    else:
        pass


