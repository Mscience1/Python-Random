from tkinter import *
import tkinter
import os
import webbrowser

root = Tk()
root.configure(background = "black")
root.geometry("260x80")
root.title("Search_Engine")

search_entry = tkinter.Entry()
search_entry.grid(row = 6, column = 1, padx = 5, pady = 5)

def btn_press():

    string_search_entry = search_entry.get()
    webbrowser.open(string_search_entry)
    print(string_search_entry)

search_txt = tkinter.Label(text = "Search Engine",bg = "gold")
search_txt.grid(row = 5, column = 1, padx = 10, pady = 5)
search_txt.config(font=("Algerian", 10))

search_btn = tkinter.Button(text = "Search", command = lambda:btn_press(), bg = "blue")
search_btn.grid(row = 6, column = 2, padx = 5, pady = 5)

root.bind("<Return>",lambda i: btn_press())

root.mainloop()

