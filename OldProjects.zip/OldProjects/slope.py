i = 0
while(i<100):
    i += 1

    if (i % 3) % 2 == 0:
        print(i)

