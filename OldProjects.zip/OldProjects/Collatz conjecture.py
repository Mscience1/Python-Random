def collatz():
    n = int(input("Input Positive Integer "))
    while(n!=1):
       if(n%2==0):
           n = n*3+1
           print(n)
       else:
           n = 0.5*n
           print(n)

collatz()
