from tkinter import*
import time

while(True):
    root = Tk()
    m = Label(root, text = 'Error, Deleting all files')
    m.pack()
    root.mainloop()
