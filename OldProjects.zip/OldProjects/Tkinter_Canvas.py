import tkinter
from tkinter import *
import time

WIDTH_CANVAS = 500
HEIGHT_CANVAS = 500

root = Tk()
draw_canvas = Canvas(root,width = WIDTH_CANVAS, height = HEIGHT_CANVAS)
root.title("Ball Wall Bounce")
draw_canvas.pack()

ball = draw_canvas.create_oval(10,10,60,60, fill = "blue")
xspeed = 5
yspeed = 6

while True:
    draw_canvas.move(ball, xspeed, yspeed)
    pos = draw_canvas.coords(ball)

    if pos[3] >= 500 or pos[1] <= 0:
        yspeed = -yspeed

    if pos[2] >= 500 or pos[0] <=0:
        xspeed = -xspeed

    root.update()
    time.sleep(0.02)

#Window Loop
root.mainloop()


