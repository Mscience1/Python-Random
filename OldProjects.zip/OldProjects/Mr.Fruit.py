import time
Fruitlist = {" grapes"," apples"," oranges"," cherries"," watermelons"," strawberries"}
FruitQ = input("What's your favorite fruit?").lower()
TotalFruit = 0
while(True):
    for fruit in Fruitlist:
        if fruit==FruitQ:
            print("Looks like we have something in common, you have great taste!")
            TotalFruit+=1
            print("Total Fruits in common,", TotalFruit, "Fruit" )
            time.sleep(999999)

    else:
        print("Not a bad choice")
        break
