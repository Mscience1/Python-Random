def array(start, stop, step):
    n = start
    i = 0
    while (i == 0):

        if (n >= start and n < stop):
            print(n)

        else:
            i = 1

        n = n + step


array(1, 80, 2)