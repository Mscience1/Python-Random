import matplotlib.pyplot as plt

yolo = 10E-4


def f(x):
    return -x ** 2 - 3 * x + 4


def func(f, x1, x2):
    dx = (x2 - x1) / 100
    x = x1
    while x <= x2:
        plt.plot([1], [0], marker='o', markersize=3, color="blue")
        plt.plot([-4], [0], marker='o', markersize=3, color="blue")
        plt.plot([-1 * (3 / 2)], [25 / 4], marker='o', markersize=3, color="yellow")

        if (f(x) > 0):
            plt.plot(x, f(x), 'r.')

        else:
            plt.plot(x, f(x), 'g.')

        x = x + dx


plt.xlabel('x', fontsize=16, color='red')
plt.ylabel('y', fontsize=16, color='red')
plt.title('$f(x)=-x^2-3x+4$', fontsize=24, color='m')
plt.grid(True)
func(f, -2, 2)
