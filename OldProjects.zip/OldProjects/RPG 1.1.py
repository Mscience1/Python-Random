import time
print("Welcome to my world")
time.sleep(2)
print("You just woke up in a car")
c1 = input("you can exit the car or you can stay in the car what will you do?")
if (c1==" stay"):
    print("you just found a mysterious phone")
    print("The phone rings")
    c2 = input("Will you answer the phone")
    if (c2==" yes"):
        print("You receive an email with a location")
        time.sleep(2)
        print("Firetech Camp")
        c3 = input ("Will you go to that location?")
        if(c3 ==" yes"):
            print("you arrive")
            print("You find a laptop with some code on the screen")
            c4 = input("Will you approach?")
            if (c4==" yes"):
                print("you see some writing above the code THE MATRIX")
                time.sleep(2)
                print("THE END")

elif(c1==" exit"):
    print("A mysterious man comes to help you")
    c5 = input("Will you talk to him?")
    if(c5==" yes"):
            print("He gives you a piece of paper with a location")
            time.sleep(2)
            print("Firetech Camp")
            c6 = input("Will you go to that location?")
            if(c6==" yes"):
                print("You arrive")
                print("you find a laptop with some code on the screen")
                c7 = input("will you approach?")
                if(c7 == " yes"):
                    print("you see some writting above the code NEO")
                    time.sleep(2)
                    print("THE END")


